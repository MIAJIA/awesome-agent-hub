"use client"

import { useState } from "react"
import { ChevronLeft, ChevronRight, ShoppingCart, Gamepad2, FileText } from "lucide-react"
import AgentCard from "./agent-card"
import AgentDetailModal from "./agent-detail-modal"
import { Button } from "@/components/ui/button"

const categories = [
  {
    id: "commerce",
    name: "🛒 Commerce Agents",
    icon: ShoppingCart,
    agents: [
      {
        name: "ShopBot Pro",
        slug: "shopbot-pro",
        description:
          "Advanced e-commerce assistant that helps users find products, compare prices, and complete purchases across multiple platforms.",
        highlight: "AI shopping assistant for price comparison and purchase automation",
        purpose: "Streamline online shopping with intelligent product discovery and automated purchasing workflows",
        repository: "https://github.com/example/shopbot-pro",
        stars: 1247,
        category: "commerce",
        originator: "TechCorp Labs",
        principle:
          "Uses web scraping, NLP, and machine learning to understand user preferences and navigate e-commerce sites",
        stack: ["Python", "FastAPI", "OpenAI", "Selenium", "PostgreSQL"],
        tags: ["e-commerce", "price-comparison", "automation", "shopping"],
        reusability:
          "Modular architecture with well-documented APIs. Supports Docker deployment and can be integrated into existing e-commerce platforms.",
        limitations:
          "Requires API keys for external services. Performance may vary based on target site complexity. Currently supports English language only.",
        status: "production" as const,
        open_source: true,
        license: "MIT",
        useful_links: ["https://docs.shopbot-pro.com", "https://tutorial.shopbot-pro.com"],
        last_updated: "2024-01-15",
        language: "Python",
        platforms: ["Docker", "AWS", "Google Cloud"],
      },
      {
        name: "Inventory Oracle",
        slug: "inventory-oracle",
        description:
          "Smart inventory management agent that predicts demand, optimizes stock levels, and automates reordering.",
        highlight: "Predictive inventory management with automated reordering",
        purpose: "Optimize inventory levels and reduce stockouts through AI-powered demand forecasting",
        repository: "https://github.com/example/inventory-oracle",
        stars: 892,
        category: "commerce",
        originator: "Supply Chain Solutions",
        principle:
          "Machine learning models analyze historical data, seasonal trends, and market indicators to predict demand",
        stack: ["Python", "TensorFlow", "PostgreSQL", "Redis"],
        tags: ["inventory", "prediction", "automation", "supply-chain"],
        reusability: "REST API with webhook support. Integrates with major ERP systems and e-commerce platforms.",
        limitations:
          "Requires 6+ months of historical data for accurate predictions. Performance depends on data quality.",
        status: "beta" as const,
        open_source: false,
        license: "Apache-2.0",
        useful_links: ["https://docs.inventory-oracle.com"],
        last_updated: "2024-01-12",
        language: "Python",
        platforms: ["Linux", "Docker", "Kubernetes"],
      },
      {
        name: "Review Analyzer",
        slug: "review-analyzer",
        description: "Analyzes customer reviews and feedback to provide actionable insights for product improvement.",
        highlight: "AI-powered customer review analysis and insights",
        purpose: "Transform customer feedback into actionable business intelligence",
        repository: "https://github.com/example/review-analyzer",
        stars: 634,
        category: "commerce",
        originator: "DataInsights Inc",
        principle: "Natural language processing and sentiment analysis to extract themes and emotions from reviews",
        stack: ["Python", "NLTK", "Transformers", "FastAPI"],
        tags: ["reviews", "sentiment-analysis", "insights", "nlp"],
        reusability: "Plugin architecture supports multiple review platforms. Easy integration via REST API.",
        limitations: "Currently optimized for English reviews. Requires manual tuning for domain-specific terminology.",
        status: "alpha" as const,
        open_source: true,
        license: "MIT",
        useful_links: ["https://github.com/example/review-analyzer/wiki"],
        last_updated: "2024-01-10",
        language: "Python",
        platforms: ["Linux", "macOS", "Windows"],
      },
    ],
  },
  {
    id: "gaming",
    name: "🎮 Gaming Agents",
    icon: Gamepad2,
    agents: [
      {
        name: "GameMaster AI",
        slug: "gamemaster-ai",
        description:
          "Dynamic dungeon master for tabletop RPGs that creates immersive storylines and manages game mechanics.",
        highlight: "AI dungeon master for tabletop RPGs with dynamic storytelling",
        purpose: "Enhance tabletop RPG experiences with AI-generated content and automated game management",
        repository: "https://github.com/example/gamemaster-ai",
        stars: 2156,
        category: "gaming",
        originator: "RPG Innovations",
        principle:
          "Large language models combined with game rule engines to generate contextual narratives and manage mechanics",
        stack: ["Python", "OpenAI", "Discord.py", "SQLite"],
        tags: ["rpg", "storytelling", "game-master", "tabletop"],
        reusability: "Modular system supports multiple RPG systems. Discord bot and web interface available.",
        limitations:
          "Requires OpenAI API key. May occasionally generate inconsistent narratives. Best with human oversight.",
        status: "production" as const,
        open_source: true,
        license: "GPL-3.0",
        useful_links: ["https://docs.gamemaster-ai.com", "https://community.gamemaster-ai.com"],
        last_updated: "2024-01-14",
        language: "Python",
        platforms: ["Discord", "Web", "Slack"],
      },
      {
        name: "Strategy Coach",
        slug: "strategy-coach",
        description: "Analyzes gameplay patterns and provides strategic advice for competitive gaming.",
        highlight: "AI coach for competitive gaming strategy and improvement",
        purpose: "Help competitive gamers improve their skills through AI-powered analysis and coaching",
        repository: "https://github.com/example/strategy-coach",
        stars: 1543,
        category: "gaming",
        originator: "Esports Analytics",
        principle:
          "Computer vision and machine learning analyze gameplay footage to identify patterns and suggest improvements",
        stack: ["Python", "OpenCV", "TensorFlow", "FastAPI"],
        tags: ["strategy", "coaching", "competitive", "analysis"],
        reusability:
          "Supports multiple game formats through plugin system. API available for integration with streaming platforms.",
        limitations: "Currently supports limited game titles. Requires high-quality video input for accurate analysis.",
        status: "beta" as const,
        open_source: false,
        license: "Commercial",
        useful_links: [],
        last_updated: "2024-01-13",
        language: "Python",
        platforms: ["Windows", "macOS", "Linux"],
      },
    ],
  },
  {
    id: "productivity",
    name: "📝 Productivity Agents",
    icon: FileText,
    agents: [
      {
        name: "Meeting Summarizer",
        slug: "meeting-summarizer",
        description: "Automatically transcribes and summarizes meetings, extracting action items and key decisions.",
        highlight: "AI meeting transcription and summarization with action items",
        purpose: "Transform meeting recordings into actionable summaries and follow-up tasks",
        repository: "https://github.com/example/meeting-summarizer",
        stars: 3421,
        category: "productivity",
        originator: "ProductivityAI",
        principle: "Speech-to-text transcription combined with NLP for content analysis and summarization",
        stack: ["Python", "Whisper", "OpenAI", "FastAPI", "PostgreSQL"],
        tags: ["meetings", "transcription", "summarization", "productivity"],
        reusability:
          "REST API with webhook support. Integrates with Zoom, Teams, and Google Meet. Plugin architecture for custom workflows.",
        limitations:
          "Audio quality affects transcription accuracy. Currently optimized for English. Requires internet connection for processing.",
        status: "production" as const,
        open_source: true,
        license: "MIT",
        useful_links: ["https://docs.meeting-summarizer.com", "https://integrations.meeting-summarizer.com"],
        last_updated: "2024-01-16",
        language: "Python",
        platforms: ["Web", "Zoom", "Microsoft Teams", "Google Meet"],
      },
      {
        name: "Task Optimizer",
        slug: "task-optimizer",
        description:
          "Intelligently prioritizes and schedules tasks based on deadlines, importance, and available time.",
        highlight: "Smart task prioritization and scheduling assistant",
        purpose: "Optimize personal and team productivity through intelligent task management",
        repository: "https://github.com/example/task-optimizer",
        stars: 1876,
        category: "productivity",
        originator: "Workflow Labs",
        principle:
          "Optimization algorithms consider multiple factors including deadlines, dependencies, and resource availability",
        stack: ["Python", "Optimization Libraries", "Calendar APIs", "React"],
        tags: ["task-management", "scheduling", "optimization", "productivity"],
        reusability:
          "Calendar integration with Google, Outlook, and Apple. REST API for custom integrations. Mobile app available.",
        limitations:
          "Requires calendar access for optimal scheduling. Learning period needed for personalized recommendations.",
        status: "alpha" as const,
        open_source: true,
        license: "Apache-2.0",
        useful_links: ["https://github.com/example/task-optimizer/wiki", "https://roadmap.task-optimizer.com"],
        last_updated: "2024-01-11",
        language: "Python",
        platforms: ["Web", "iOS", "Android", "Desktop"],
      },
    ],
  },
]

export default function FeaturedAgents() {
  const [selectedAgent, setSelectedAgent] = useState(null)
  const [scrollPositions, setScrollPositions] = useState<Record<string, number>>({})

  const scrollCategory = (categoryId: string, direction: "left" | "right") => {
    const container = document.getElementById(`category-${categoryId}`)
    if (container) {
      const scrollAmount = 280 // Adjusted for mobile
      const newPosition =
        direction === "left"
          ? Math.max(0, (scrollPositions[categoryId] || 0) - scrollAmount)
          : (scrollPositions[categoryId] || 0) + scrollAmount

      container.scrollTo({ left: newPosition, behavior: "smooth" })
      setScrollPositions((prev) => ({ ...prev, [categoryId]: newPosition }))
    }
  }

  return (
    <section className="py-8 sm:py-16 px-4">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-8 sm:mb-12">
          <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">Featured Agents by Category</h2>
          <p className="text-gray-400 text-base sm:text-lg">Discover AI agents organized by their primary use cases</p>
        </div>

        <div className="space-y-8 sm:space-y-12">
          {categories.map((category) => (
            <div key={category.id} className="relative">
              <div className="flex items-center justify-between mb-4 sm:mb-6">
                <h3 className="text-xl sm:text-2xl font-semibold text-white flex items-center">
                  <category.icon className="w-5 h-5 sm:w-6 sm:h-6 mr-2 sm:mr-3 text-blue-400" />
                  <span className="truncate">{category.name}</span>
                </h3>
                <div className="flex space-x-1 sm:space-x-2">
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => scrollCategory(category.id, "left")}
                    className="text-gray-400 hover:text-white h-8 w-8 sm:h-auto sm:w-auto"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => scrollCategory(category.id, "right")}
                    className="text-gray-400 hover:text-white h-8 w-8 sm:h-auto sm:w-auto"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              <div
                id={`category-${category.id}`}
                className="flex space-x-4 sm:space-x-6 overflow-x-auto scrollbar-hide pb-4"
                style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
              >
                {category.agents.map((agent) => (
                  <div key={agent.slug} className="flex-none w-72 sm:w-80">
                    <AgentCard agent={agent} onViewDetails={setSelectedAgent} />
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      {selectedAgent && <AgentDetailModal agent={selectedAgent} onClose={() => setSelectedAgent(null)} />}
    </section>
  )
}
