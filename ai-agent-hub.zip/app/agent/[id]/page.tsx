"use client"

import { useState } from "react"
import {
  Star,
  Github,
  Play,
  ExternalLink,
  Calendar,
  Shield,
  Code,
  CopyrightIcon as License,
  ArrowLeft,
  Heart,
} from "lucide-react"
import Link from "next/link"
import Navigation from "@/components/navigation"
import AgentCard from "@/components/agent-card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

// Mock agent data - in real app this would come from API
const agentData = {
  id: "1",
  name: "ShopBot Pro",
  description:
    "ShopBot Pro is an advanced e-commerce assistant that revolutionizes online shopping by providing intelligent product discovery, real-time price comparison across multiple platforms, and automated purchase workflows. Built with cutting-edge AI technology, it understands natural language queries and can navigate complex e-commerce sites to find exactly what users are looking for.\n\nThe agent features advanced price tracking capabilities, inventory monitoring, and can even predict price drops based on historical data. It integrates seamlessly with major e-commerce platforms including Amazon, eBay, Shopify stores, and many others.",
  shortDescription: "AI shopping assistant for price comparison and purchase automation",
  stars: 1247,
  category: "Commerce",
  tags: ["e-commerce", "price-comparison", "automation", "shopping", "ai-assistant", "web-scraping"],
  isProductionReady: true,
  isOpenSource: true,
  repoUrl: "https://github.com/example/shopbot-pro",
  demoUrl: "https://demo.shopbot-pro.com",
  avatar: "🛒",
  techStack: ["Python", "FastAPI", "OpenAI", "Selenium", "PostgreSQL", "Redis"],
  license: "MIT",
  lastUpdated: "2024-01-15",
  author: "TechCorp Labs",
  downloads: 15420,
  forks: 234,
}

const relatedAgents = [
  {
    id: "2",
    name: "Inventory Oracle",
    description:
      "Smart inventory management agent that predicts demand, optimizes stock levels, and automates reordering.",
    shortDescription: "Predictive inventory management with automated reordering",
    stars: 892,
    category: "Commerce",
    tags: ["inventory", "prediction", "automation", "supply-chain"],
    isProductionReady: true,
    isOpenSource: false,
    repoUrl: "https://github.com/example/inventory-oracle",
    avatar: "📦",
    techStack: ["Python", "TensorFlow", "PostgreSQL"],
    license: "Apache 2.0",
    lastUpdated: "2024-01-12",
  },
  {
    id: "3",
    name: "Review Analyzer",
    description: "Analyzes customer reviews and feedback to provide actionable insights for product improvement.",
    shortDescription: "AI-powered customer review analysis and insights",
    stars: 634,
    category: "Commerce",
    tags: ["reviews", "sentiment-analysis", "insights", "nlp"],
    isProductionReady: false,
    isOpenSource: true,
    repoUrl: "https://github.com/example/review-analyzer",
    demoUrl: "https://demo.review-analyzer.com",
    avatar: "⭐",
    techStack: ["Python", "NLTK", "Transformers"],
    license: "MIT",
    lastUpdated: "2024-01-10",
  },
]

export default function AgentDetailPage() {
  const [isStarred, setIsStarred] = useState(false)

  return (
    <div className="min-h-screen bg-gray-900">
      <Navigation />

      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Back Button */}
        <Link href="/" className="inline-flex items-center text-gray-400 hover:text-white mb-8 transition-colors">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Hub
        </Link>

        {/* Header */}
        <div className="bg-gradient-to-br from-gray-800/50 to-gray-900/50 rounded-2xl p-8 border border-gray-700/50 mb-8 backdrop-blur-sm">
          <div className="flex items-start justify-between mb-6">
            <div className="flex items-center space-x-6">
              <div className="w-20 h-20 bg-gradient-to-r from-blue-500 to-purple-600 rounded-2xl flex items-center justify-center text-white font-bold text-3xl">
                {agentData.avatar}
              </div>
              <div>
                <h1 className="text-4xl font-bold text-white mb-2">{agentData.name}</h1>
                <div className="flex items-center space-x-4 mb-3">
                  <Badge variant="secondary" className="text-sm">
                    {agentData.category}
                  </Badge>
                  <div className="flex items-center text-gray-400">
                    <Star className="w-4 h-4 mr-1 fill-yellow-400 text-yellow-400" />
                    {agentData.stars} stars
                  </div>
                  <span className="text-gray-400">•</span>
                  <span className="text-gray-400">{agentData.downloads.toLocaleString()} downloads</span>
                  <span className="text-gray-400">•</span>
                  <span className="text-gray-400">{agentData.forks} forks</span>
                </div>
                <p className="text-gray-300 text-lg">{agentData.shortDescription}</p>
              </div>
            </div>

            <div className="flex space-x-3">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setIsStarred(!isStarred)}
                className={`border-gray-600 ${isStarred ? "bg-yellow-600/20 text-yellow-400 border-yellow-600/30" : "text-gray-300 hover:bg-gray-800"}`}
              >
                <Star className={`w-4 h-4 mr-2 ${isStarred ? "fill-current" : ""}`} />
                {isStarred ? "Starred" : "Star"}
              </Button>
              <Button variant="outline" size="sm" className="border-gray-600 text-gray-300 hover:bg-gray-800">
                <Heart className="w-4 h-4 mr-2" />
                Save
              </Button>
            </div>
          </div>

          <div className="flex flex-wrap gap-3 mb-6">
            {agentData.isProductionReady && (
              <Badge className="bg-green-600/20 text-green-400 border-green-600/30">
                <Shield className="w-3 h-3 mr-1" />
                Production Ready
              </Badge>
            )}
            {agentData.isOpenSource && (
              <Badge className="bg-blue-600/20 text-blue-400 border-blue-600/30">
                <Code className="w-3 h-3 mr-1" />
                Open Source
              </Badge>
            )}
          </div>

          <div className="flex space-x-4">
            <Button className="bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white">
              <Github className="w-4 h-4 mr-2" />
              View Repository
            </Button>
            <Button variant="outline" className="border-gray-600 text-gray-300 hover:bg-gray-800">
              <Play className="w-4 h-4 mr-2" />
              Try Demo
            </Button>
            <Button variant="outline" className="border-gray-600 text-gray-300 hover:bg-gray-800">
              <ExternalLink className="w-4 h-4 mr-2" />
              Documentation
            </Button>
          </div>
        </div>

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Left Column - Description */}
          <div className="lg:col-span-2 space-y-8">
            <div className="bg-gradient-to-br from-gray-800/50 to-gray-900/50 rounded-2xl p-6 border border-gray-700/50 backdrop-blur-sm">
              <h2 className="text-2xl font-semibold text-white mb-4">Description</h2>
              <div className="prose prose-invert max-w-none">
                {agentData.description.split("\n\n").map((paragraph, index) => (
                  <p key={index} className="text-gray-300 leading-relaxed mb-4">
                    {paragraph}
                  </p>
                ))}
              </div>
            </div>

            <div className="bg-gradient-to-br from-gray-800/50 to-gray-900/50 rounded-2xl p-6 border border-gray-700/50 backdrop-blur-sm">
              <h2 className="text-2xl font-semibold text-white mb-4">Tech Stack</h2>
              <div className="flex flex-wrap gap-3">
                {agentData.techStack.map((tech) => (
                  <Badge key={tech} variant="outline" className="border-blue-600/30 text-blue-400 text-sm px-3 py-1">
                    {tech}
                  </Badge>
                ))}
              </div>
            </div>

            <div className="bg-gradient-to-br from-gray-800/50 to-gray-900/50 rounded-2xl p-6 border border-gray-700/50 backdrop-blur-sm">
              <h2 className="text-2xl font-semibold text-white mb-4">Reusability & Integration</h2>
              <div className="space-y-4">
                <div className="p-4 bg-green-600/10 border border-green-600/30 rounded-lg">
                  <h3 className="text-green-400 font-medium mb-2">✅ Easy Integration</h3>
                  <p className="text-gray-300 text-sm">
                    Modular architecture with well-documented APIs. Supports Docker deployment, cloud functions, and can
                    be integrated into existing e-commerce platforms.
                  </p>
                </div>
                <div className="p-4 bg-blue-600/10 border border-blue-600/30 rounded-lg">
                  <h3 className="text-blue-400 font-medium mb-2">🔧 Customizable</h3>
                  <p className="text-gray-300 text-sm">
                    Extensive configuration options for different use cases. Plugin system allows for custom
                    integrations with proprietary systems.
                  </p>
                </div>
                <div className="p-4 bg-yellow-600/10 border border-yellow-600/30 rounded-lg">
                  <h3 className="text-yellow-400 font-medium mb-2">⚠️ Requirements</h3>
                  <p className="text-gray-300 text-sm">
                    Requires API keys for e-commerce platforms. Performance scales with infrastructure. Currently
                    optimized for English-language sites.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column - Metadata */}
          <div className="space-y-6">
            <div className="bg-gradient-to-br from-gray-800/50 to-gray-900/50 rounded-2xl p-6 border border-gray-700/50 backdrop-blur-sm">
              <h3 className="text-lg font-semibold text-white mb-4">Details</h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-gray-400 flex items-center">
                    <License className="w-4 h-4 mr-2" />
                    License
                  </span>
                  <span className="text-white">{agentData.license}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-400 flex items-center">
                    <Calendar className="w-4 h-4 mr-2" />
                    Last Updated
                  </span>
                  <span className="text-white">{agentData.lastUpdated}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-400">Author</span>
                  <span className="text-white">{agentData.author}</span>
                </div>
              </div>
            </div>

            <div className="bg-gradient-to-br from-gray-800/50 to-gray-900/50 rounded-2xl p-6 border border-gray-700/50 backdrop-blur-sm">
              <h3 className="text-lg font-semibold text-white mb-4">Tags</h3>
              <div className="flex flex-wrap gap-2">
                {agentData.tags.map((tag) => (
                  <span
                    key={tag}
                    className="px-3 py-1 bg-gray-700/50 text-gray-300 text-sm rounded-lg hover:bg-gray-600/50 cursor-pointer transition-colors"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Related Agents */}
        <div className="mt-16">
          <h2 className="text-3xl font-bold text-white mb-8">Related Agents</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {relatedAgents.map((agent) => (
              <AgentCard key={agent.id} agent={agent} onViewDetails={() => {}} />
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
